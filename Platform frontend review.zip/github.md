repo: dgoeaa/ECM_DOCS_DEV
branch: main

## Last sync

date: 2026-08-05T16:20:00Z

### Updated in this project
- Rebuilt the Root Platform as a single Design Component on the NITDA design system: fit-to-screen shell, 9 visible workspaces, 20 guided internal routes, role-derived navigation.
- Rebuilt the Document Portal as a separate Design Component: home, four-step submit, verified tracking, support and helpdesk.
- Added light / dark / high-contrast themes and comfortable / compact density across both, driven by the design system's own theme and density token files.
- Both apps now share the brand and the environment but run independently — cross-links only, no shared state.

## Screen map

| Screen | Built from |
| --- | --- |
| Root Platform — shell, sidebar, topbar, footer | shared/shell.js, config/nav.config.js, config/routes.config.js |
| Root Platform — Command Center | modules/home.js, config/workflow-clarity.config.js |
| Root Platform — Intake & Assignment | modules/correspondence.js, modules/single-assignment.js, config/correspondence-categories.config.js |
| Root Platform — My Work / Departmental Work | modules/orchestrator.js, modules/acknowledgment.js, modules/comments.js |
| Root Platform — Tracking & Monitoring | modules/response-tracking.js, modules/reports.js, modules/statistics.js |
| Root Platform — Review & Approval | modules/approvals.js, modules/executive.js |
| Root Platform — Dispatch & Archive | modules/dispatch.js, modules/archive.js |
| Root Platform — Correspondence Email Desk | modules/correspondence-email.js, config/correspondence-email-templates.config.js |
| Root Platform — ERP–ECM Charter | modules/ecm-erp-charter.js |
| Root Platform — Administration | modules/settings.js, modules/user-admin.js, modules/diagnostics.js, modules/operator-hud.js, config/endpoints.config.js |
| Root Platform — guided internal routes | config/workflow-clarity.config.js (HiddenTechnicalRoutes) |
| Root Platform — role gating | config/rbac.config.js, config/priority.config.js |
| Document Portal — home | document-portal/index.html, document-portal/js/home.js, document-portal/js/data.js |
| Document Portal — submit | document-portal/submit.html, document-portal/js/submit.js |
| Document Portal — track | document-portal/track.html, document-portal/js/track.js |
| Document Portal — support | document-portal/support.html, document-portal/js/support.js |

## Sync history

- 2026-08-05T04:20:00Z — first read of the repository and the document-portal sources.
